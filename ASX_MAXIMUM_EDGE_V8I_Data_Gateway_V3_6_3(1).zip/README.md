# ASX MAXIMUM EDGE™ V8-I Data Gateway V3.6.3

WebSocket endurance reliability, authoritative manifest status, precise collection timing, and watchdog hardening release.

Key changes from V3.6.2:
- Accurate V3.6.3 version reporting and request metadata.
- Separate setup elapsed time from market-data collection elapsed time.
- Monotonic collection deadline with 1-second receive slices to prevent long blocking waits.
- Collection overrun telemetry and explicit deadline-enforcement field.
- Overall worker watchdog retained with bounded setup + collection + small finalization grace.
- Persistent manifest treated as authoritative for terminal status; stale RUNNING visibility is reconciled when terminal fields exist.
- Execution authorization remains separately controlled and NOT_GRANTED.
