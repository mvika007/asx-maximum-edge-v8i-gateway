# ASX MAXIMUM EDGE™ V8-I Data Gateway V3.6.2

## WebSocket Endurance Reliability & Watchdog Edition

V3.6.2 is a reliability-focused patch over V3.6.1. It does **not** grant execution authorization.

### Key changes
- Bounded hard wall-clock timeout for every background WebSocket acceptance worker.
- No indefinite RUNNING state is permitted after the hard worker deadline.
- Timeout finalization records `HARD_WORKER_TIMEOUT` and marks the job `FAILED`.
- Persistent manifest records `hard_timeout_seconds` and `deadline_at`.
- Gateway/version metadata consistently reports V3.6.2.
- Fixes the stale request metadata that previously reported gateway version 3.6.
- Existing heartbeat, orphan detection, connection retry, subscription retry, timestamp freshness, progression and gap telemetry retained.
- Execution authorization remains separately denied until acceptance evidence warrants promotion.

### Default timeout
For a requested streaming duration `D`, the background worker is bounded to `D + 30 seconds` by default. Configure with `ASX_V8I_WS_HARD_TIMEOUT_GRACE_SECONDS`.

This is a safety bound, not an assertion that the provider can sustain the requested duration.

### Acceptance policy
A successful short capability test proves capability only. Sustained streaming quality must be demonstrated by completed endurance runs with verified fresh timestamps, timestamp progression, adequate event coverage and no invalid timestamps.
